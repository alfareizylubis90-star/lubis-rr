let masterStaff = []; // Semua staf (master data)
let lemburanData = {}; // Data lemburan per bulan: {'2026-05': {staffIndex: {day: {jam: 2}}}}
let currentMonth = 5; // Januari = 0, Juni = 5
let currentYear = 2026;
const monthNames = [
    'JANUARI', 'FEBRUARI', 'MARET', 'APRIL', 'MEI', 'JUNI',
    'JULI', 'AGUSTUS', 'SEPTEMBER', 'OKTOBER', 'NOVEMBER', 'DESEMBER'
];

document.addEventListener('DOMContentLoaded', function() {
    loadData();
    changeMonth();
    
    document.getElementById('staffForm').addEventListener('submit', handleStaffSubmit);
    document.getElementById('lemburForm').addEventListener('submit', handleLemburSubmit);
});

function getCurrentKey() {
    return `${currentYear}-${String(currentMonth).padStart(2, '0')}`;
}

function getLemburanForMonth() {
    const key = getCurrentKey();
    return lemburanData[key] || {};
}

function loadData() {
    const savedStaff = localStorage.getItem('masterStaff');
    const savedLemburan = localStorage.getItem('lemburanData');
    
    if (savedStaff) {
        masterStaff = JSON.parse(savedStaff);
    }
    
    if (savedLemburan) {
        lemburanData = JSON.parse(savedLemburan);
    }
}

function saveData() {
    localStorage.setItem('masterStaff', JSON.stringify(masterStaff));
    localStorage.setItem('lemburanData', JSON.stringify(lemburanData));
}

function updatePageTitle() {
    const titleElement = document.getElementById('pageTitle');
    titleElement.textContent = `LEMBURAN LIGA BANDOT ${monthNames[currentMonth]} ${currentYear}`;
}

function changeMonth() {
    currentMonth = parseInt(document.getElementById('monthSelect').value);
    currentYear = parseInt(document.getElementById('yearSelect').value);
    updatePageTitle();
    renderTable();
}

function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

function parseNumber(str) {
    return parseFloat(str.replace(/[.,]/g, '')) || 0;
}

function renderTable() {
    const csTbody = document.getElementById('csTableBody');
    const csLineTbody = document.getElementById('csLineTableBody');
    const kasirTbody = document.getElementById('kasirTableBody');
    const kksTbody = document.getElementById('kksTableBody');
    
    csTbody.innerHTML = '';
    csLineTbody.innerHTML = '';
    kasirTbody.innerHTML = '';
    kksTbody.innerHTML = '';
    
    let csCounter = 0;
    let csLineCounter = 0;
    let kasirCounter = 0;
    let kksCounter = 0;
    
    const currentLemburan = getLemburanForMonth();
    
    masterStaff.forEach((staff, index) => {
        const row = document.createElement('tr');
        
        let totalLembur = 0;
        for (let day = 1; day <= 31; day++) {
            if (currentLemburan[index] && currentLemburan[index][day] && currentLemburan[index][day].jam) {
                totalLembur += parseFloat(currentLemburan[index][day].jam);
            }
        }
        
        const maxGaji = staff.maxGaji || 0;
        const ratePerJam = maxGaji / 30 / 10;
        const totalHasil = Math.round(totalLembur * ratePerJam);
        
        let dayCells = '';
        for (let day = 1; day <= 31; day++) {
            const lemburData = currentLemburan[index] ? currentLemburan[index][day] : null;
            const hasValue = lemburData && lemburData.jam;
            const cellContent = hasValue ? lemburData.jam : '';
            dayCells += `<td class="day-cell ${hasValue ? 'has-value' : ''}" onclick="openLemburModal(${index}, ${day})">${cellContent}</td>`;
        }
        
        let counter = 0;
        let targetTbody;
        
        if (staff.jabatan === 'CS LINE') {
            csLineCounter++;
            counter = csLineCounter;
            targetTbody = csLineTbody;
        } else if (staff.jabatan === 'CS') {
            csCounter++;
            counter = csCounter;
            targetTbody = csTbody;
        } else if (staff.jabatan === 'KASIR') {
            kasirCounter++;
            counter = kasirCounter;
            targetTbody = kasirTbody;
        } else if (staff.jabatan === 'KKS') {
            kksCounter++;
            counter = kksCounter;
            targetTbody = kksTbody;
        } else {
            // Handle old LAINNYA data
            kksCounter++;
            counter = kksCounter;
            targetTbody = kksTbody;
        }
        
        row.innerHTML = `
            <td>${counter}</td>
            <td>${staff.namaStaf}</td>
            <td>${staff.jabatan}</td>
            <td>${totalLembur}</td>
            <td>${totalHasil.toLocaleString('id-ID')}</td>
            ${dayCells}
        `;
        targetTbody.appendChild(row);
    });
}

function openStaffManagerModal() {
    renderStaffManagerTable();
    document.getElementById('staffManagerModal').style.display = 'block';
}

function closeStaffManagerModal() {
    document.getElementById('staffManagerModal').style.display = 'none';
}

function renderStaffManagerTable() {
    const tbody = document.getElementById('staffManagerTableBody');
    tbody.innerHTML = '';
    
    masterStaff.forEach((staff, index) => {
        const row = document.createElement('tr');
        
        row.innerHTML = `
            <td>${index + 1}</td>
            <td style="text-align: left; padding-left: 20px;">${staff.namaStaf}</td>
            <td>${staff.jabatan}</td>
            <td style="font-weight: 600; color: #2e7d32;">${staff.maxGaji ? formatNumber(staff.maxGaji) : '-'}</td>
            <td>
                <button class="action-btn edit-staff-btn" onclick="openEditStaffModal(${index}); closeStaffManagerModal();">Edit</button>
                <button class="action-btn delete-staff-btn" onclick="deleteStaff(${index});">Hapus</button>
            </td>
        `;
        
        tbody.appendChild(row);
    });
}

function openAddStaffModal() {
    document.getElementById('modalTitle').textContent = 'Tambah Staf';
    document.getElementById('staffForm').reset();
    document.getElementById('editStaffId').value = '';
    document.getElementById('modal').style.display = 'block';
}

function openEditStaffModal(index) {
    const staff = masterStaff[index];
    document.getElementById('modalTitle').textContent = 'Edit Staf';
    document.getElementById('namaStaf').value = staff.namaStaf;
    document.getElementById('jabatan').value = staff.jabatan;
    document.getElementById('maxGaji').value = staff.maxGaji ? formatNumber(staff.maxGaji) : '';
    document.getElementById('editStaffId').value = index;
    document.getElementById('modal').style.display = 'block';
}

function closeModal() {
    document.getElementById('modal').style.display = 'none';
}

function handleStaffSubmit(e) {
    e.preventDefault();
    
    const editId = document.getElementById('editStaffId').value;
    const newStaff = {
        namaStaf: document.getElementById('namaStaf').value,
        jabatan: document.getElementById('jabatan').value,
        maxGaji: parseNumber(document.getElementById('maxGaji').value)
    };
    
    if (editId !== '') {
        masterStaff[editId] = newStaff;
    } else {
        masterStaff.push(newStaff);
    }
    
    saveData();
    renderTable();
    
    // If staff manager modal is open, rerender it
    if (document.getElementById('staffManagerModal').style.display === 'block') {
        renderStaffManagerTable();
    }
    
    closeModal();
}

function deleteStaff(index) {
    if (confirm('Apakah Anda yakin ingin menghapus staf ini? (semua data lemburan juga akan dihapus)')) {
        masterStaff.splice(index, 1);
        
        // Hapus lemburan staf ini dari semua bulan
        Object.keys(lemburanData).forEach(key => {
            if (lemburanData[key][index]) {
                delete lemburanData[key][index];
            }
            // Perbaiki indeks staf di data lemburan
            const newLemburan = {};
            Object.keys(lemburanData[key]).forEach(oldIdx => {
                const idx = parseInt(oldIdx);
                if (idx < index) {
                    newLemburan[idx] = lemburanData[key][idx];
                } else if (idx > index) {
                    newLemburan[idx - 1] = lemburanData[key][idx];
                }
            });
            lemburanData[key] = newLemburan;
        });
        
        saveData();
        renderTable();
        
        // If staff manager modal is open, rerender it
        if (document.getElementById('staffManagerModal').style.display === 'block') {
            renderStaffManagerTable();
        }
    }
}

function openLemburModal(staffIndex, day) {
    const staff = masterStaff[staffIndex];
    document.getElementById('staffId').value = staffIndex;
    document.getElementById('dayNumber').value = day;
    document.getElementById('lemburModalTitle').textContent = `Input Lemburan - ${staff.namaStaf} - Tanggal ${day}`;
    
    const currentLemburan = getLemburanForMonth();
    const existingData = currentLemburan[staffIndex] && currentLemburan[staffIndex][day];
    if (existingData) {
        document.getElementById('jamLembur').value = existingData.jam;
    } else {
        document.getElementById('lemburForm').reset();
    }
    
    document.getElementById('lemburModal').style.display = 'block';
}

function closeLemburModal() {
    document.getElementById('lemburModal').style.display = 'none';
}

function handleLemburSubmit(e) {
    e.preventDefault();
    
    const staffIndex = parseInt(document.getElementById('staffId').value);
    const day = parseInt(document.getElementById('dayNumber').value);
    const jamLembur = document.getElementById('jamLembur').value;
    
    const key = getCurrentKey();
    if (!lemburanData[key]) {
        lemburanData[key] = {};
    }
    if (!lemburanData[key][staffIndex]) {
        lemburanData[key][staffIndex] = {};
    }
    
    lemburanData[key][staffIndex][day] = {
        jam: jamLembur
    };
    
    saveData();
    renderTable();
    closeLemburModal();
}
